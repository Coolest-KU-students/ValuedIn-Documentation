# IO.Swagger.Model.ChatMessage
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreatedOn** | **DateTime?** |  | [optional] 
**CreatedBy** | **string** |  | [optional] 
**Id** | **long?** |  | [optional] 
**ChatId** | **long?** |  | 
**Message** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

