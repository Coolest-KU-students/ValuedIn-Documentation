# IO.Swagger.Model.UpdatedUser
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UserID** | **string** |  | [optional] 
**FirstName** | **string** |  | [optional] 
**LastName** | **string** |  | [optional] 
**Role** | **string** |  | [optional] 
**Email** | **string** |  | [optional] 
**Telephone** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

