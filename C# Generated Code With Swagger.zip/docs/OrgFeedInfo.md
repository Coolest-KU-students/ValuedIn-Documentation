# IO.Swagger.Model.OrgFeedInfo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**OrganizationBanner** | **List&lt;string&gt;** |  | [optional] 
**OrganizationTitle** | **string** |  | [optional] 
**OrganizationDescription** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

