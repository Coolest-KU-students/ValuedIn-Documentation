# IO.Swagger.Model.NewChatRequest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Participants** | **List&lt;string&gt;** |  | [optional] 
**MessageContent** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

