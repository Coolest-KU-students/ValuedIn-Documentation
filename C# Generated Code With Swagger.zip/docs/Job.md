# IO.Swagger.Model.Job
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**JobAvatar** | **List&lt;string&gt;** |  | [optional] 
**JobTitle** | **string** |  | [optional] 
**JobTags** | **List&lt;string&gt;** |  | [optional] 
**JobValues** | **List&lt;string&gt;** |  | [optional] 
**JobMatch** | **long?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

