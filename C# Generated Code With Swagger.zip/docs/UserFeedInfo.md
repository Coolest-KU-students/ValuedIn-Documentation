# IO.Swagger.Model.UserFeedInfo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UserFirstName** | **string** |  | [optional] 
**UserLastName** | **string** |  | [optional] 
**UserPosition** | **string** |  | [optional] 
**UserMatch** | [**decimal?**](BigDecimal.md) |  | [optional] 
**UserValues** | **List&lt;string&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

