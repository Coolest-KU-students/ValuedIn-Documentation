# IO.Swagger.Api.ChatsApi

All URIs are relative to *https://virtserver.swaggerhub.com/iramasauskas/ValuedIn/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateChat**](ChatsApi.md#createchat) | **POST** /chats | Create Chat
[**CreateMsg**](ChatsApi.md#createmsg) | **POST** /chats/{id} | Create a Message in Chat
[**ListChats**](ChatsApi.md#listchats) | **GET** /chats | List all Chats
[**ViewChat**](ChatsApi.md#viewchat) | **GET** /chats/{id} | View Chat

<a name="createchat"></a>
# **CreateChat**
> Chat CreateChat (NewChatRequest body = null)

Create Chat

This can only be done by the logged in user.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CreateChatExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ChatsApi();
            var body = new NewChatRequest(); // NewChatRequest |  (optional) 

            try
            {
                // Create Chat
                Chat result = apiInstance.CreateChat(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ChatsApi.CreateChat: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**NewChatRequest**](NewChatRequest.md)|  | [optional] 

### Return type

[**Chat**](Chat.md)

### Authorization

[valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/_*+json
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="createmsg"></a>
# **CreateMsg**
> ChatMessage CreateMsg (long? id, NewMessage body = null)

Create a Message in Chat

This can only be done by the logged in user.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CreateMsgExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ChatsApi();
            var id = 789;  // long? | 
            var body = new NewMessage(); // NewMessage | Provide message content (optional) 

            try
            {
                // Create a Message in Chat
                ChatMessage result = apiInstance.CreateMsg(id, body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ChatsApi.CreateMsg: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **long?**|  | 
 **body** | [**NewMessage**](NewMessage.md)| Provide message content | [optional] 

### Return type

[**ChatMessage**](ChatMessage.md)

### Authorization

[valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/_*+json
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="listchats"></a>
# **ListChats**
> ChatInfoPage ListChats (string pageToken)

List all Chats

This can only be done by the logged in user.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ListChatsExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ChatsApi();
            var pageToken = pageToken_example;  // string | 

            try
            {
                // List all Chats
                ChatInfoPage result = apiInstance.ListChats(pageToken);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ChatsApi.ListChats: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pageToken** | **string**|  | 

### Return type

[**ChatInfoPage**](ChatInfoPage.md)

### Authorization

[valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="viewchat"></a>
# **ViewChat**
> MessageDTODateTimeOffsetPage ViewChat (long? id, string pageToken)

View Chat

This can only be done by the logged in user.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ViewChatExample
    {
        public void main()
        {
            var apiInstance = new ChatsApi();
            var id = 789;  // long? | ID of chat to return
            var pageToken = pageToken_example;  // string | 

            try
            {
                // View Chat
                MessageDTODateTimeOffsetPage result = apiInstance.ViewChat(id, pageToken);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ChatsApi.ViewChat: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **long?**| ID of chat to return | 
 **pageToken** | **string**|  | 

### Return type

[**MessageDTODateTimeOffsetPage**](MessageDTODateTimeOffsetPage.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
