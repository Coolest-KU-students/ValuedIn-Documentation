# IO.Swagger.Api.AuthenticationApi

All URIs are relative to *https://virtserver.swaggerhub.com/iramasauskas/ValuedIn/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ChangePass**](AuthenticationApi.md#changepass) | **POST** /auth/passwordchange | Change password
[**CheckAuth**](AuthenticationApi.md#checkauth) | **GET** /auth | Check authentication
[**LogINUser**](AuthenticationApi.md#loginuser) | **POST** /auth | Login by user
[**RegUser**](AuthenticationApi.md#reguser) | **POST** /auth/register | Register User account
[**ResetPass**](AuthenticationApi.md#resetpass) | **POST** /auth/passwordreset | Reset password

<a name="changepass"></a>
# **ChangePass**
> void ChangePass (NewPassword body)

Change password

This can only be done by the logged in user.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ChangePassExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new AuthenticationApi();
            var body = new NewPassword(); // NewPassword | Created user object

            try
            {
                // Change password
                apiInstance.ChangePass(body);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AuthenticationApi.ChangePass: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**NewPassword**](NewPassword.md)| Created user object | 

### Return type

void (empty response body)

### Authorization

[valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: application/json, application/xml, application/x-www-form-urlencoded
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="checkauth"></a>
# **CheckAuth**
> void CheckAuth ()

Check authentication

Check authentication

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CheckAuthExample
    {
        public void main()
        {
            var apiInstance = new AuthenticationApi();

            try
            {
                // Check authentication
                apiInstance.CheckAuth();
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AuthenticationApi.CheckAuth: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="loginuser"></a>
# **LogINUser**
> string LogINUser (AuthRequest body = null)

Login by user

Log in by user

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class LogINUserExample
    {
        public void main()
        {
            var apiInstance = new AuthenticationApi();
            var body = new AuthRequest(); // AuthRequest | Log in request (optional) 

            try
            {
                // Login by user
                string result = apiInstance.LogINUser(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AuthenticationApi.LogINUser: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**AuthRequest**](AuthRequest.md)| Log in request | [optional] 

### Return type

**string**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml, application/x-www-form-urlencoded
 - **Accept**: application/xml, application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="reguser"></a>
# **RegUser**
> NewUser RegUser (NewUser body)

Register User account

Register User account

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class RegUserExample
    {
        public void main()
        {
            var apiInstance = new AuthenticationApi();
            var body = new NewUser(); // NewUser | Created user object

            try
            {
                // Register User account
                NewUser result = apiInstance.RegUser(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AuthenticationApi.RegUser: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**NewUser**](NewUser.md)| Created user object | 

### Return type

[**NewUser**](NewUser.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml, application/x-www-form-urlencoded
 - **Accept**: application/json, application/xml, application/x-www-form-urlencoded

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="resetpass"></a>
# **ResetPass**
> void ResetPass ()

Reset password

Reset the password for the user

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ResetPassExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new AuthenticationApi();

            try
            {
                // Reset password
                apiInstance.ResetPass();
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AuthenticationApi.ResetPass: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
