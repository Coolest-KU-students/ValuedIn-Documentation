# IO.Swagger.Model.AllOfFeedResults
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UserFirstName** | **string** |  | [optional] 
**UserLastName** | **string** |  | [optional] 
**UserPosition** | **string** |  | [optional] 
**UserMatch** | [**decimal?**](BigDecimal.md) |  | [optional] 
**UserValues** | **List&lt;string&gt;** |  | [optional] 
**JobAvatar** | **List&lt;string&gt;** |  | [optional] 
**JobTitle** | **string** |  | [optional] 
**JobTags** | **List&lt;string&gt;** |  | [optional] 
**JobValues** | **List&lt;string&gt;** |  | [optional] 
**JobMatch** | **long?** |  | [optional] 
**OrganizationBanner** | **List&lt;string&gt;** |  | [optional] 
**OrganizationTitle** | **string** |  | [optional] 
**OrganizationDescription** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

