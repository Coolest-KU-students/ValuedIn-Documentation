# IO.Swagger.Model.JobSysInfo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** |  | [optional] 
**Avatar** | **List&lt;string&gt;** |  | [optional] 
**Title** | **string** |  | 
**Position** | **string** |  | [optional] 
**Location** | **string** |  | [optional] 
**JobDescription** | **string** |  | [optional] 
**Values** | **string** |  | [optional] 
**Match** | **long?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

