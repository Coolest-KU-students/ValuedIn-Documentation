# IO.Swagger.Model.Chat
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreatedOn** | **DateTime?** |  | [optional] 
**CreatedBy** | **string** |  | [optional] 
**Id** | **long?** |  | [optional] 
**Messages** | [**List&lt;ChatMessage&gt;**](ChatMessage.md) |  | 
**Participants** | [**List&lt;ChatParticipant&gt;**](ChatParticipant.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

