# IO.Swagger.Model.ChatParticipant
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreatedOn** | **DateTime?** |  | [optional] 
**CreatedBy** | **string** |  | [optional] 
**UpdatedOn** | **DateTime?** |  | [optional] 
**UpdatedBy** | **string** |  | [optional] 
**UserId** | **string** |  | [optional] 
**ChatId** | **long?** |  | 
**Chat** | [**Chat**](Chat.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

