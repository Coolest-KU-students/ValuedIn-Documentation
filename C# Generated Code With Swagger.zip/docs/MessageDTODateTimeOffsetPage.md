# IO.Swagger.Model.MessageDTODateTimeOffsetPage
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Results** | [**List&lt;MessageDTO&gt;**](MessageDTO.md) |  | [optional] 
**NextOffset** | **DateTime?** |  | [optional] 
**Last** | **bool?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

