# IO.Swagger.Api.FeedApi

All URIs are relative to *https://virtserver.swaggerhub.com/iramasauskas/ValuedIn/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ListFeed**](FeedApi.md#listfeed) | **GET** /feed | List all Feed elements

<a name="listfeed"></a>
# **ListFeed**
> FeedInfoPage ListFeed ()

List all Feed elements

This can only be done by the logged in user.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ListFeedExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new FeedApi();

            try
            {
                // List all Feed elements
                FeedInfoPage result = apiInstance.ListFeed();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling FeedApi.ListFeed: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**FeedInfoPage**](FeedInfoPage.md)

### Authorization

[valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml, application/x-www-form-urlencoded

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
