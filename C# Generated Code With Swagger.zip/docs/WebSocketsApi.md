# IO.Swagger.Api.WebSocketsApi

All URIs are relative to *https://virtserver.swaggerhub.com/iramasauskas/ValuedIn/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**WebSocket**](WebSocketsApi.md#websocket) | **GET** /ws | Establish Web Socket
[**WebSocketToekn**](WebSocketsApi.md#websockettoekn) | **GET** /ws/token | Provides a web socket token

<a name="websocket"></a>
# **WebSocket**
> void WebSocket ()

Establish Web Socket

Establish Web Socket

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class WebSocketExample
    {
        public void main()
        {
            var apiInstance = new WebSocketsApi();

            try
            {
                // Establish Web Socket
                apiInstance.WebSocket();
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling WebSocketsApi.WebSocket: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="websockettoekn"></a>
# **WebSocketToekn**
> void WebSocketToekn ()

Provides a web socket token

Provides a token for the user to establish a web socket

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class WebSocketToeknExample
    {
        public void main()
        {
            var apiInstance = new WebSocketsApi();

            try
            {
                // Provides a web socket token
                apiInstance.WebSocketToekn();
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling WebSocketsApi.WebSocketToekn: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
