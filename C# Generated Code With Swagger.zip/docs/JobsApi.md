# IO.Swagger.Api.JobsApi

All URIs are relative to *https://virtserver.swaggerhub.com/iramasauskas/ValuedIn/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ApplyJob**](JobsApi.md#applyjob) | **POST** /jobs/{id}/applications | Apply to Job
[**ArchJob**](JobsApi.md#archjob) | **DELETE** /jobs/{id} | Archive Job
[**BookJob**](JobsApi.md#bookjob) | **POST** /jobs/bookmarks/{id} | Bookmark Job
[**CreateJob**](JobsApi.md#createjob) | **POST** /jobs/{id} | Create new Job
[**ListFeedJobs**](JobsApi.md#listfeedjobs) | **GET** /jobs/feed | List all Feed elements of Jobs
[**ListJobs**](JobsApi.md#listjobs) | **GET** /jobs | List all Jobs
[**UnbookJob**](JobsApi.md#unbookjob) | **DELETE** /jobs/bookmarks/{id} | Un-bookmark Job
[**UpdateJob**](JobsApi.md#updatejob) | **PUT** /jobs/{id} | Update Job
[**ViewAppJob**](JobsApi.md#viewappjob) | **GET** /jobs/{id}/applications | View applicants to Job
[**ViewBookJob**](JobsApi.md#viewbookjob) | **GET** /jobs/bookmarks | View bookmarked Jobs
[**ViewJob**](JobsApi.md#viewjob) | **GET** /jobs/{id} | View Job

<a name="applyjob"></a>
# **ApplyJob**
> Job ApplyJob (long? id)

Apply to Job

This can only be done by the logged in user.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ApplyJobExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new JobsApi();
            var id = 789;  // long? | ID of job to to apply to

            try
            {
                // Apply to Job
                Job result = apiInstance.ApplyJob(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling JobsApi.ApplyJob: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **long?**| ID of job to to apply to | 

### Return type

[**Job**](Job.md)

### Authorization

[valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="archjob"></a>
# **ArchJob**
> void ArchJob (long? id)

Archive Job

This can only be done by the logged in user.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ArchJobExample
    {
        public void main()
        {
            var apiInstance = new JobsApi();
            var id = 789;  // long? | ID of job to archive

            try
            {
                // Archive Job
                apiInstance.ArchJob(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling JobsApi.ArchJob: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **long?**| ID of job to archive | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="bookjob"></a>
# **BookJob**
> Job BookJob (long? id)

Bookmark Job

This can only be done by the logged in user.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class BookJobExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new JobsApi();
            var id = 789;  // long? | ID of job to bookmark

            try
            {
                // Bookmark Job
                Job result = apiInstance.BookJob(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling JobsApi.BookJob: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **long?**| ID of job to bookmark | 

### Return type

[**Job**](Job.md)

### Authorization

[valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="createjob"></a>
# **CreateJob**
> Job CreateJob (Job body, long? id)

Create new Job

This can only be done by HR role.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CreateJobExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new JobsApi();
            var body = new Job(); // Job | Create a new job in the social network
            var id = 789;  // long? | ID of organization where job will be created

            try
            {
                // Create new Job
                Job result = apiInstance.CreateJob(body, id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling JobsApi.CreateJob: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Job**](Job.md)| Create a new job in the social network | 
 **id** | **long?**| ID of organization where job will be created | 

### Return type

[**Job**](Job.md)

### Authorization

[valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="listfeedjobs"></a>
# **ListFeedJobs**
> JobInfoPage ListFeedJobs (string feedToken)

List all Feed elements of Jobs

This can only be done by the logged in user.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ListFeedJobsExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new JobsApi();
            var feedToken = feedToken_example;  // string | 

            try
            {
                // List all Feed elements of Jobs
                JobInfoPage result = apiInstance.ListFeedJobs(feedToken);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling JobsApi.ListFeedJobs: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feedToken** | **string**|  | 

### Return type

[**JobInfoPage**](JobInfoPage.md)

### Authorization

[valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml, application/x-www-form-urlencoded

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="listjobs"></a>
# **ListJobs**
> JobSystemInfoPage ListJobs (string pageToken)

List all Jobs

List all existing jobs

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ListJobsExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new JobsApi();
            var pageToken = pageToken_example;  // string | 

            try
            {
                // List all Jobs
                JobSystemInfoPage result = apiInstance.ListJobs(pageToken);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling JobsApi.ListJobs: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pageToken** | **string**|  | 

### Return type

[**JobSystemInfoPage**](JobSystemInfoPage.md)

### Authorization

[valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml, application/x-www-form-urlencoded

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="unbookjob"></a>
# **UnbookJob**
> Job UnbookJob (long? id)

Un-bookmark Job

This can only be done by the logged in user.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class UnbookJobExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new JobsApi();
            var id = 789;  // long? | ID of job to un-bookmark

            try
            {
                // Un-bookmark Job
                Job result = apiInstance.UnbookJob(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling JobsApi.UnbookJob: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **long?**| ID of job to un-bookmark | 

### Return type

[**Job**](Job.md)

### Authorization

[valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="updatejob"></a>
# **UpdateJob**
> Job UpdateJob (Job body, long? id)

Update Job

This can only be done by HR role.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class UpdateJobExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new JobsApi();
            var body = new Job(); // Job | Update an existent job in social network
            var id = 789;  // long? | ID of job to return

            try
            {
                // Update Job
                Job result = apiInstance.UpdateJob(body, id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling JobsApi.UpdateJob: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Job**](Job.md)| Update an existent job in social network | 
 **id** | **long?**| ID of job to return | 

### Return type

[**Job**](Job.md)

### Authorization

[valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="viewappjob"></a>
# **ViewAppJob**
> AppInfoPage ViewAppJob (long? id)

View applicants to Job

This can only be done by the logged in user.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ViewAppJobExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new JobsApi();
            var id = 789;  // long? | ID of job to return applicants

            try
            {
                // View applicants to Job
                AppInfoPage result = apiInstance.ViewAppJob(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling JobsApi.ViewAppJob: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **long?**| ID of job to return applicants | 

### Return type

[**AppInfoPage**](AppInfoPage.md)

### Authorization

[valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="viewbookjob"></a>
# **ViewBookJob**
> JobInfoPage ViewBookJob ()

View bookmarked Jobs

This can only be done by the logged in user.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ViewBookJobExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new JobsApi();

            try
            {
                // View bookmarked Jobs
                JobInfoPage result = apiInstance.ViewBookJob();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling JobsApi.ViewBookJob: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**JobInfoPage**](JobInfoPage.md)

### Authorization

[valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="viewjob"></a>
# **ViewJob**
> Job ViewJob (long? id)

View Job

This can only be done by the logged in user.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ViewJobExample
    {
        public void main()
        {
            // Configure API key authorization: api_key
            Configuration.Default.AddApiKey("jwt_token", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("jwt_token", "Bearer");
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new JobsApi();
            var id = 789;  // long? | ID of job to return

            try
            {
                // View Job
                Job result = apiInstance.ViewJob(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling JobsApi.ViewJob: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **long?**| ID of job to return | 

### Return type

[**Job**](Job.md)

### Authorization

[api_key](../README.md#api_key), [valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
