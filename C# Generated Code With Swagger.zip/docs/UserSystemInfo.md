# IO.Swagger.Model.UserSystemInfo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Login** | **string** |  | [optional] 
**UserID** | **string** |  | [optional] 
**IsExpired** | **bool?** |  | [optional] 
**LastActive** | **DateTime?** |  | [optional] 
**Role** | **string** |  | [optional] 
**FirstName** | **string** |  | [optional] 
**LastName** | **string** |  | [optional] 
**Email** | **string** |  | [optional] 
**Telephone** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

