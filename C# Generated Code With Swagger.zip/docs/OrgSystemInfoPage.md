# IO.Swagger.Model.OrgSystemInfoPage
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Results** | [**List&lt;OrgSystemInfo&gt;**](OrgSystemInfo.md) |  | [optional] 
**Total** | **int?** |  | [optional] 
**PageNo** | **int?** |  | [optional] 
**Count** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

