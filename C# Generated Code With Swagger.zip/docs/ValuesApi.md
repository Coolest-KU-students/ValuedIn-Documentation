# IO.Swagger.Api.ValuesApi

All URIs are relative to *https://virtserver.swaggerhub.com/iramasauskas/ValuedIn/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ArchValue**](ValuesApi.md#archvalue) | **DELETE** /values | Archive Value
[**ListValues**](ValuesApi.md#listvalues) | **GET** /values | List all Values
[**SysCreateValue**](ValuesApi.md#syscreatevalue) | **POST** /values | Create new Value for Sys Admin
[**UpdateValues**](ValuesApi.md#updatevalues) | **PUT** /values | Update Value

<a name="archvalue"></a>
# **ArchValue**
> void ArchValue (string name)

Archive Value

This can only be done by the System Admin.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ArchValueExample
    {
        public void main()
        {
            var apiInstance = new ValuesApi();
            var name = name_example;  // string | Name to filter by

            try
            {
                // Archive Value
                apiInstance.ArchValue(name);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ValuesApi.ArchValue: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **string**| Name to filter by | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="listvalues"></a>
# **ListValues**
> ValueInfoPage ListValues (string pageToken)

List all Values

List all existing values

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ListValuesExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ValuesApi();
            var pageToken = pageToken_example;  // string | 

            try
            {
                // List all Values
                ValueInfoPage result = apiInstance.ListValues(pageToken);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ValuesApi.ListValues: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pageToken** | **string**|  | 

### Return type

[**ValueInfoPage**](ValueInfoPage.md)

### Authorization

[valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="syscreatevalue"></a>
# **SysCreateValue**
> Value SysCreateValue (Value body)

Create new Value for Sys Admin

This can only be done by system admin.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SysCreateValueExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ValuesApi();
            var body = new Value(); // Value | Create a new value in the social network

            try
            {
                // Create new Value for Sys Admin
                Value result = apiInstance.SysCreateValue(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ValuesApi.SysCreateValue: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Value**](Value.md)| Create a new value in the social network | 

### Return type

[**Value**](Value.md)

### Authorization

[valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="updatevalues"></a>
# **UpdateValues**
> Value UpdateValues (Value body, string name = null)

Update Value

Update an existent value in social network

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class UpdateValuesExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ValuesApi();
            var body = new Value(); // Value | Update an existent value in social network
            var name = name_example;  // string | Name to filter by (optional) 

            try
            {
                // Update Value
                Value result = apiInstance.UpdateValues(body, name);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ValuesApi.UpdateValues: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Value**](Value.md)| Update an existent value in social network | 
 **name** | **string**| Name to filter by | [optional] 

### Return type

[**Value**](Value.md)

### Authorization

[valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
