# IO.Swagger.Api.OrganizationsApi

All URIs are relative to *https://virtserver.swaggerhub.com/iramasauskas/ValuedIn/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ArchiveOrg**](OrganizationsApi.md#archiveorg) | **DELETE** /organizations/{id} | Archive Organization
[**CreateOrg**](OrganizationsApi.md#createorg) | **POST** /organizations | Add a new organization to the social network
[**ListFeedOrg**](OrganizationsApi.md#listfeedorg) | **GET** /organizations/feed | List all Feed elements of Organizations
[**ListOrg**](OrganizationsApi.md#listorg) | **GET** /organizations | List all Organizations
[**ListOrgEmp**](OrganizationsApi.md#listorgemp) | **GET** /organizations/{id}/employees | List all Organization Employees
[**RequestReg**](OrganizationsApi.md#requestreg) | **POST** /organizations/request | Request new Company Registration
[**UpdateOrg**](OrganizationsApi.md#updateorg) | **PUT** /organizations/{id} | Update Organization
[**ViewOrg**](OrganizationsApi.md#vieworg) | **GET** /organizations/{id} | Find organization by ID
[**ViewOrgJob**](OrganizationsApi.md#vieworgjob) | **GET** /organizations/{id}/jobs | View Organization Jobs
[**ViewValueHis**](OrganizationsApi.md#viewvaluehis) | **POST** /organizations/{id}/valuehistory | View Organization Value history

<a name="archiveorg"></a>
# **ArchiveOrg**
> void ArchiveOrg (long? id)

Archive Organization

Archive an existent organization in social

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ArchiveOrgExample
    {
        public void main()
        {
            var apiInstance = new OrganizationsApi();
            var id = 789;  // long? | ID of organization to archive

            try
            {
                // Archive Organization
                apiInstance.ArchiveOrg(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrganizationsApi.ArchiveOrg: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **long?**| ID of organization to archive | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="createorg"></a>
# **CreateOrg**
> NewOrganization CreateOrg (NewOrganization body)

Add a new organization to the social network

Add a new organization to the social network

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CreateOrgExample
    {
        public void main()
        {
            var apiInstance = new OrganizationsApi();
            var body = new NewOrganization(); // NewOrganization | Create a new organization in the social network

            try
            {
                // Add a new organization to the social network
                NewOrganization result = apiInstance.CreateOrg(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrganizationsApi.CreateOrg: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**NewOrganization**](NewOrganization.md)| Create a new organization in the social network | 

### Return type

[**NewOrganization**](NewOrganization.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="listfeedorg"></a>
# **ListFeedOrg**
> OrgFeedInfoPage ListFeedOrg (string feedToken)

List all Feed elements of Organizations

List all Feed elements of Organizations

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ListFeedOrgExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrganizationsApi();
            var feedToken = feedToken_example;  // string | 

            try
            {
                // List all Feed elements of Organizations
                OrgFeedInfoPage result = apiInstance.ListFeedOrg(feedToken);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrganizationsApi.ListFeedOrg: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feedToken** | **string**|  | 

### Return type

[**OrgFeedInfoPage**](OrgFeedInfoPage.md)

### Authorization

[valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml, application/x-www-form-urlencoded

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="listorg"></a>
# **ListOrg**
> OrgSystemInfoPage ListOrg (string pageToken)

List all Organizations

List all Organizations

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ListOrgExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrganizationsApi();
            var pageToken = pageToken_example;  // string | 

            try
            {
                // List all Organizations
                OrgSystemInfoPage result = apiInstance.ListOrg(pageToken);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrganizationsApi.ListOrg: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pageToken** | **string**|  | 

### Return type

[**OrgSystemInfoPage**](OrgSystemInfoPage.md)

### Authorization

[valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml, application/x-www-form-urlencoded

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="listorgemp"></a>
# **ListOrgEmp**
> EmployeeInfoPage ListOrgEmp (long? id, string pageToken)

List all Organization Employees

List all Organization Employees

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ListOrgEmpExample
    {
        public void main()
        {
            // Configure API key authorization: api_key
            Configuration.Default.AddApiKey("jwt_token", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("jwt_token", "Bearer");
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrganizationsApi();
            var id = 789;  // long? | ID of organization to return employees
            var pageToken = pageToken_example;  // string | 

            try
            {
                // List all Organization Employees
                EmployeeInfoPage result = apiInstance.ListOrgEmp(id, pageToken);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrganizationsApi.ListOrgEmp: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **long?**| ID of organization to return employees | 
 **pageToken** | **string**|  | 

### Return type

[**EmployeeInfoPage**](EmployeeInfoPage.md)

### Authorization

[api_key](../README.md#api_key), [valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="requestreg"></a>
# **RequestReg**
> void RequestReg ()

Request new Company Registration

Request new Company Registration

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class RequestRegExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrganizationsApi();

            try
            {
                // Request new Company Registration
                apiInstance.RequestReg();
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrganizationsApi.RequestReg: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="updateorg"></a>
# **UpdateOrg**
> OrgSystemInfo UpdateOrg (OrgSystemInfo body, long? id)

Update Organization

Update an existing organization by Id

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class UpdateOrgExample
    {
        public void main()
        {
            // Configure API key authorization: api_key
            Configuration.Default.AddApiKey("jwt_token", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("jwt_token", "Bearer");
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrganizationsApi();
            var body = new OrgSystemInfo(); // OrgSystemInfo | Update an existent organization in social network
            var id = 789;  // long? | ID of organization to return

            try
            {
                // Update Organization
                OrgSystemInfo result = apiInstance.UpdateOrg(body, id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrganizationsApi.UpdateOrg: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**OrgSystemInfo**](OrgSystemInfo.md)| Update an existent organization in social network | 
 **id** | **long?**| ID of organization to return | 

### Return type

[**OrgSystemInfo**](OrgSystemInfo.md)

### Authorization

[api_key](../README.md#api_key), [valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="vieworg"></a>
# **ViewOrg**
> OrgSystemInfo ViewOrg (long? id)

Find organization by ID

Returns a single organization

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ViewOrgExample
    {
        public void main()
        {
            // Configure API key authorization: api_key
            Configuration.Default.AddApiKey("jwt_token", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("jwt_token", "Bearer");
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrganizationsApi();
            var id = 789;  // long? | ID of organization to return

            try
            {
                // Find organization by ID
                OrgSystemInfo result = apiInstance.ViewOrg(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrganizationsApi.ViewOrg: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **long?**| ID of organization to return | 

### Return type

[**OrgSystemInfo**](OrgSystemInfo.md)

### Authorization

[api_key](../README.md#api_key), [valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="vieworgjob"></a>
# **ViewOrgJob**
> JobInfoPage ViewOrgJob (long? id, string pageToken)

View Organization Jobs

View Organization Jobs

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ViewOrgJobExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrganizationsApi();
            var id = 789;  // long? | ID of organization to return open job positions
            var pageToken = pageToken_example;  // string | 

            try
            {
                // View Organization Jobs
                JobInfoPage result = apiInstance.ViewOrgJob(id, pageToken);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrganizationsApi.ViewOrgJob: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **long?**| ID of organization to return open job positions | 
 **pageToken** | **string**|  | 

### Return type

[**JobInfoPage**](JobInfoPage.md)

### Authorization

[valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="viewvaluehis"></a>
# **ViewValueHis**
> OrgSystemInfo ViewValueHis (PaginatedDataRequest body, long? id)

View Organization Value history

This can only be done by the logged in user.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ViewValueHisExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrganizationsApi();
            var body = new PaginatedDataRequest(); // PaginatedDataRequest | Provide required page number and filter
            var id = 789;  // long? | ID of organization to return

            try
            {
                // View Organization Value history
                OrgSystemInfo result = apiInstance.ViewValueHis(body, id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrganizationsApi.ViewValueHis: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PaginatedDataRequest**](PaginatedDataRequest.md)| Provide required page number and filter | 
 **id** | **long?**| ID of organization to return | 

### Return type

[**OrgSystemInfo**](OrgSystemInfo.md)

### Authorization

[valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
