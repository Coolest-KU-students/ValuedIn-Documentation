# IO.Swagger.Model.MessageDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** |  | 
**SentByFirstName** | **string** |  | 
**SentByLastName** | **string** |  | 
**Content** | **string** |  | 
**Sent** | **DateTime?** |  | 
**Unread** | **bool?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

