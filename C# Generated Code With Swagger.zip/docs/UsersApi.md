# IO.Swagger.Api.UsersApi

All URIs are relative to *https://virtserver.swaggerhub.com/iramasauskas/ValuedIn/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ExpireUser**](UsersApi.md#expireuser) | **DELETE** /users/{id} | Expire User
[**ListFeedUsers**](UsersApi.md#listfeedusers) | **GET** /users/feed | List all Feed elements of Users
[**ListUsers**](UsersApi.md#listusers) | **GET** /users | List all Users
[**UpdateUser**](UsersApi.md#updateuser) | **PUT** /users/{id} | Update User
[**UploadCV**](UsersApi.md#uploadcv) | **POST** /users/{id}/cv | Upload CV for User
[**ViewUser**](UsersApi.md#viewuser) | **GET** /users/{id} | View User

<a name="expireuser"></a>
# **ExpireUser**
> void ExpireUser (string id)

Expire User

Expire User by ID

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ExpireUserExample
    {
        public void main()
        {
            var apiInstance = new UsersApi();
            var id = id_example;  // string | ID of user to expire

            try
            {
                // Expire User
                apiInstance.ExpireUser(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling UsersApi.ExpireUser: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **string**| ID of user to expire | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="listfeedusers"></a>
# **ListFeedUsers**
> UserFeedInfoPage ListFeedUsers (string feedToken)

List all Feed elements of Users

This can only be done by the logged in user.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ListFeedUsersExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new UsersApi();
            var feedToken = feedToken_example;  // string | 

            try
            {
                // List all Feed elements of Users
                UserFeedInfoPage result = apiInstance.ListFeedUsers(feedToken);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling UsersApi.ListFeedUsers: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feedToken** | **string**|  | 

### Return type

[**UserFeedInfoPage**](UserFeedInfoPage.md)

### Authorization

[valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml, application/x-www-form-urlencoded

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="listusers"></a>
# **ListUsers**
> UserSystemInfoPage ListUsers (string pageToken)

List all Users

This can only be done by the logged system admin.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ListUsersExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new UsersApi();
            var pageToken = pageToken_example;  // string | 

            try
            {
                // List all Users
                UserSystemInfoPage result = apiInstance.ListUsers(pageToken);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling UsersApi.ListUsers: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pageToken** | **string**|  | 

### Return type

[**UserSystemInfoPage**](UserSystemInfoPage.md)

### Authorization

[valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml, application/x-www-form-urlencoded

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="updateuser"></a>
# **UpdateUser**
> void UpdateUser (UpdatedUser body, string id)

Update User

This can only be done by the logged in user.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class UpdateUserExample
    {
        public void main()
        {
            // Configure API key authorization: api_key
            Configuration.Default.AddApiKey("jwt_token", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("jwt_token", "Bearer");
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new UsersApi();
            var body = new UpdatedUser(); // UpdatedUser | 
            var id = id_example;  // string | 

            try
            {
                // Update User
                apiInstance.UpdateUser(body, id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling UsersApi.UpdateUser: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**UpdatedUser**](UpdatedUser.md)|  | 
 **id** | **string**|  | 

### Return type

void (empty response body)

### Authorization

[api_key](../README.md#api_key), [valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="uploadcv"></a>
# **UploadCV**
> ModelApiResponse UploadCV (long? id, Object body = null, string additionalMetadata = null)

Upload CV for User

This can only be done by the logged in user.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class UploadCVExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new UsersApi();
            var id = 789;  // long? | ID of user to update
            var body = new Object(); // Object |  (optional) 
            var additionalMetadata = additionalMetadata_example;  // string | Additional Metadata (optional) 

            try
            {
                // Upload CV for User
                ModelApiResponse result = apiInstance.UploadCV(id, body, additionalMetadata);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling UsersApi.UploadCV: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **long?**| ID of user to update | 
 **body** | **Object**|  | [optional] 
 **additionalMetadata** | **string**| Additional Metadata | [optional] 

### Return type

[**ModelApiResponse**](ModelApiResponse.md)

### Authorization

[valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: application/octet-stream
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="viewuser"></a>
# **ViewUser**
> UserSystemInfo ViewUser (string id)

View User

This can only be done by system admin.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ViewUserExample
    {
        public void main()
        {
            // Configure API key authorization: api_key
            Configuration.Default.AddApiKey("jwt_token", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("jwt_token", "Bearer");
            // Configure OAuth2 access token for authorization: valuedIn_auth
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new UsersApi();
            var id = id_example;  // string | 

            try
            {
                // View User
                UserSystemInfo result = apiInstance.ViewUser(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling UsersApi.ViewUser: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **string**|  | 

### Return type

[**UserSystemInfo**](UserSystemInfo.md)

### Authorization

[api_key](../README.md#api_key), [valuedIn_auth](../README.md#valuedIn_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
